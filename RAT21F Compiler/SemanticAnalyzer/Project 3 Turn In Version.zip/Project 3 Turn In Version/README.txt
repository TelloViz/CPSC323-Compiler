run the app from this directory.

// help menu
$jp -h  

// this will print the assembly, line numbered source and the symbol table
$jp -i yourSource.txt -t -a -l 